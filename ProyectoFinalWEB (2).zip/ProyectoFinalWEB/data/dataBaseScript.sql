CREATE TABLE Usuarios (
	nombre VARCHAR(30) NOT NULL,
    apellido VARCHAR(30) NOT NULL,
    correo VARCHAR(50) NOT NULL PRIMARY KEY,
    contrasena VARCHAR(50) NOT NULL
);
INSERT INTO Usuarios(nombre, apellido, correo, contrasena)
VALUES('Andrea', 'Chacon', 'andreachb@gmail.com', '230994'),
('Jose', 'Flores', 'josema@gmail.com', 'floresma');
CREATE TABLE Libros (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombreLibro VARCHAR(50) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    imagen VARCHAR(400),
    precio FLOAT NOT NULL,
    idioma VARCHAR(30) NOT NULL,
    edicion VARCHAR(30) NOT NULL,
    correoVendedor VARCHAR(50) NOT NULL,
	nombreVendedor VARCHAR(30) NOT NULL,
    apellidoVendedor VARCHAR(30) NOT NULL
);
INSERT INTO Libros(ID, nombreLibro, autor, imagen, precio, idioma, edicion, correoVendedor, nombreVendedor, apellidoVendedor)
VALUES (1, 'Ghostgirl', 'Tonya hurley', 'imagenesD/59522e1c117392.17671576.png', 356, 'ingles', 4, 'andreachb@gmail.com', 'Andrea', 'Chacon'),
(2, 'Algebra', 'A Baldor', 'imagenesD/59522f0a382b23.70042220.png', 1348, 'espanol', 2, 'josema@gmail.com', 'Jose', 'Flores'),
(3, 'Hornos', 'Olga Lengyel', 'imagenesD/5952313e017233.17143656.png', 98, 'espanol', 1, 'andreachb@gmail.com', 'Andrea', 'Chacon');


CREATE TABLE Favoritos (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    correo VARCHAR(50) NOT NULL,
    libros VARCHAR(500) NOT NULL
);