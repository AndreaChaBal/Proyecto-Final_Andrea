<?php
	header('Accept: application/json');
	header('Content-type: application/json');
	require_once __DIR__ . '/dataLayer.php';

	$action = $_POST["accion"];

	switch($action) {
		case "LOGIN" : loginFunction();
						break;
        case "REGISTRO" : registroFunction();
                        break;
		case "CATALOGO" : catalogoFunction();
						break;
        case "PORNOMBRE": buscarPorNombre();
                        break;
        case "PORAUTOR" : buscarPorAutor();
                        break;
        case "SESION" : checarSesion();
                        break;
        case "DATOSVENDEDOR" : obtenerDatosVendedor();
                                break;
        case "CARGARCUENTA" : checarSesion();
                                break;
        case "GUARDARCUENTA" : guardarCuenta();
                                break;
        case "LOGUT" : eliminarSesion();
                        break;
        case "AGREGARFAVORITO" : agregarFav();
                                    break;
        case "QUITARFAVORITO" : quitarFav();
                                    break;
        case "MOSTRARFAVORITO" : mostrarFav();
                                    break;
		case "SUBIRLIBRO"    : subirLibro();
								break;
        case "SUBIDOS" : cargarSubidos();
                        break;
	}

    function loginFunction() {
		$uCorreo = $_POST["uCorreo"];
		$uPassword = $_POST["uPassword"];

		$response = attemptLogin($uCorreo, $uPassword);

		if ($response["status"] == "EXITO") {
			startSession($response["nombre"], $response["apellido"], $uCorreo, $uPassword);
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
	}

    function registroFunction(){
		$uNombre = $_POST["nombre"];
		$uApellido = $_POST["apellido"];
		$uCorreo = $_POST["correo"];
		$uPassword = $_POST["contrasena"];
        
        $response =  attemptRegister($uNombre, $uApellido, $uCorreo, $uPassword);
        
		if ($response["status"] == "EXITO") {
			startSession($uNombre, $uApellido, $uCorreo, $uPassword);
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
    }

	function catalogoFunction(){
		$response = cargarTodos();
		if ($response[0]["status"] == "EXITO") {
		    echo json_encode($response);
		 } 
		else {
			errorHandling($response["status"]);
		}
	}

    function buscarPorNombre(){
		$uNombre = $_POST["nombre"];
		$response = queryNombre($uNombre);
		if ($response[0]["status"] == "EXITO") {
		    echo json_encode($response);
		 } 
		else {
			errorHandling($response["status"]);
		}
    }

    function buscarPorAutor(){
		$uAutor = $_POST["autor"];
		$response = queryAutor($uAutor);
		if ($response[0]["status"] == "EXITO") {
		    echo json_encode($response);
		 } 
		else {
			errorHandling($response["status"]);
		}
    }

	function startSession($uNombre, $uApellido, $uCorreo, $uPassword) {
		session_start();
		$_SESSION["nombre"] = $uNombre;
		$_SESSION["apellido"] = $uApellido;
		$_SESSION["correo"] = $uCorreo;
		$_SESSION["contrasena"] = $uPassword;
	}

    function checarSesion() {
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            echo json_encode(array("correo" => $_SESSION["correo"], "contrasena" => $_SESSION["contrasena"], 
                                   "nombre" => $_SESSION["nombre"], "apellido" => $_SESSION["apellido"]));
        } else {
            header('HTTP/1.1 406 Sesion expirada.');
            die("Tu sesion ha expirado.");
        }
    }

    function guardarCuenta(){
		$uNombre = $_POST["nombre"];
        $uApellido = $_POST["apellido"];
        $uContrasena = $_POST["contrasena"];
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            $uCorreo = $_SESSION["correo"];
        }
        $response = modificarUsuario($uNombre, $uApellido, $uContrasena, $uCorreo);
		if ($response["status"] == "EXITO") {
            session_start();
            if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {   
                $_SESSION["nombre"] = $uNombre;
                $_SESSION["apellido"] = $uApellido;
                $_SESSION["correo"] = $uCorreo;
                $_SESSION["contrasena"] = $uContrasena;
            }
			echo json_encode($response);
		 } 
		else {
			errorHandling($response["status"]);
		}
    }
    
    function obtenerDatosVendedor(){
		$uCorreo = $_POST["correo"];
        
        $response =  obtenerVendedor($uCorreo);
        
		if ($response["status"] == "EXITO") {
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
    }

    function eliminarSesion(){
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            unset($_SESSION["correo"]);
            unset($_SESSION["contrasena"]);
            unset($_SESSION["nombre"]);
            unset($_SESSION["apellido"]);
            session_destroy();
            echo json_encode(array("status" => "EXITO"));
        } else {
            header('HTTP/1.1 406 Sesion expirada.');
            die("Tu sesion ha expirado o no fue creada con anterioridad");
        }
    }
    
    function subirLibro(){
			$nombreLibro = $_POST["nombreLibro"];
			$autor = $_POST["autor"];
			$imagen = $_POST["imagen"];
			$precio = $_POST["precio"];
			$idioma = $_POST["idioma"];
			$edicion = $_POST["edicion"];
			$correoVendedor = $_POST["correoVendedor"];
			$nombreVendedor = $_POST["nombreVendedor"];
			$apellidoVendedor = $_POST["apellidoVendedor"];
			
	        $response =   attemptSubirL($nombreLibro, $autor, $imagen, $precio, $idioma, $edicion, $correoVendedor, $nombreVendedor, $apellidoVendedor);
	        
			if ($response["status"] == "EXITO") {
				
				echo json_encode($response);
			} else {
				errorHandling($response["status"]);
			}
	}

    function agregarFav(){
        $uNombre = $_POST["nombre"];
        
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            $uCorreo = $_SESSION["correo"];
        }
        $response =  insertarFav($uNombre, $uCorreo);
        
		if ($response["status"] == "EXITO") {
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
    }
/*
    function quitarFav(){
        $uNombre = $_POST["nombre"];
        
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            $uCorreo = $_SESSION["correo"];
        }
        $response =  eliminarFav($uNombre, $uCorreo);
        
		if ($response["status"] == "EXITO") {
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
    }
*/
    function mostrarFav(){
        session_start();
        if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
            $uCorreo = $_SESSION["correo"];
        }
        $response =  desplegarFav($uCorreo);
        
		if ($response["status"] == "EXITO") {
			echo json_encode($response);
		} else {
			errorHandling($response["status"]);
		}
    }

function cargarSubidos(){
	session_start();
	if (isset($_SESSION["correo"]) && isset($_SESSION["contrasena"]) && isset($_SESSION["nombre"]) && isset($_SESSION["apellido"])) {
	    $uCorreo = $_SESSION["correo"];
    }
    $response = cargarLibrosSubidos($uCorreo);
	if ($response[0]["status"] == "EXITO") {
		    echo json_encode($response);
    } else {
        errorHandling($response["status"]);
    }
}

	function errorHandling($errorStatus) {
        switch ($errorStatus) {
			case "406" : header('HTTP/1.1 406 Usuario no encontrado.');
						die("El usuario y contraseña no coinciden con alguna cuenta.");
						break;
            case "407" : header('HTTP/1.1 406 Usuario previamente creado.');
                        die("Ya existe un usuario con el mismo nombre, elige otro.");
						break;
			case "408" : header("HTTP/1.1 406 No se ha podido crear el usuario.");
                        die("No se ha podido crear el nuevo usuario.");
						break;
			case "409"  : header('HTTP/1.1 406 No hay libros en la base de datos.');
						die("No hay libros en la base de datos.");
						break;
            case "410" : header('HTTP/1.1 406 No hay libros con el nombre dado.');
						die("No hay libros con el nombre dado.");
						break;
            case "411" : header('HTTP/1.1 406 No hay libros con el autor dado.');
						die("No hay libros con el autor dado.");
						break;
            case "412" : header('HTTP/1.1 406 Error al recuperar al vendedor del libro.');
						die("Error al recuperar al vendedor del libro.");
						break;
            case "413" : header('HTTP/1.1 406 Error al guardar los nuevos datos de la cuenta.');
						die("Error al guardar los nuevos datos de la cuenta.");
						break;
            case "414" : header('HTTP/1.1 406 Error al guardar los nuevos datos de favoritos.');
						die("Error al guardar los nuevos datos de favoritos.");
						break;
            case "415" : header('HTTP/1.1 406 Error al cargar datos de favoritos.');
						die("No hay datos de favoritos en la cuenta.");
						break;
            case "416" : header('HTTP/1.1 406 Error al dar update a datos de favoritos.');
						die("Error al dar update a datos de favoritos.");
						break;
            case "417" : header('HTTP/1.1 406 No hay datos de favoritos.');
						die("No hay datos de favoritos.");
						break;
            case "418" : header('HTTP/1.1 406 No hay datos de libros subidos.');
						die("No hay datos de libros subidos.");
						break;
			case "500" : header('HTTP/1.1 500 Mala coneccion a la BD.');
						die("El servidor está caído, inténtelo nuevamente.");
						break;
		}
	}
?>
