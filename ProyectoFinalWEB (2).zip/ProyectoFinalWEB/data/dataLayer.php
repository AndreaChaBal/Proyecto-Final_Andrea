<?php
	
	function connectionToDataBase() {
		$servername = "localhost";
		$username = "root";
		$passwrd = "root";
		$dbname = "books2sell";

		$conn = new mysqli($servername, $username, $passwrd, $dbname);

        if ($conn -> connect_error) {
			return null;
		}
		else {
			return $conn;
		} 
	}

	function attemptLogin($uCorreo, $uPassword) {
		
		$connection = connectionToDataBase();

		if ($connection != null) {
			$sql = "SELECT nombre, apellido FROM usuarios WHERE correo ='$uCorreo' AND contrasena ='$uPassword'";
		
			$result = $connection->query($sql);

			if ($result->num_rows > 0) {
				while ($row = $result->fetch_assoc()) {
					$response = array("status" => "EXITO", "nombre"=>$row["nombre"], "apellido"=>$row["apellido"]);
				}
				$connection -> close();
				return $response;
			} else{
				$connection -> close();
				return array("status" => "406");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
	}

	function attemptRegister($uNombre, $uApellido, $uCorreo, $uPassword) {
		
		$connection = connectionToDataBase();

		if ($connection != null) {
			$sql = "SELECT * FROM usuarios WHERE correo ='$uCorreo'";
		
			$result = $connection->query($sql);

			if ($result->num_rows == 0) {
                $sqldos = "INSERT INTO usuarios (nombre, apellido, correo, contrasena) VALUES ('$uNombre', '$uApellido', '$uCorreo', '$uPassword')";
                    if ($connection -> query($sqldos) === TRUE){
                        $response = array("status" => "EXITO");
                        $connection -> close();
                        return $response;
                    } else {
                        $connection -> close();
                        return array("status" => "408");
                    }
            } else {
				$connection -> close();
				return array("status" => "407");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
	}
	
	function cargarTodos(){
		$connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM Libros";
			$result = $connection -> query($sql);
			if ($result ->num_rows > 0){
				$response = array();
				while($row = $result -> fetch_assoc()){
					$dummyResponse = array("status" => "EXITO","nombreLibro" => $row["nombreLibro"], "autor" => $row["autor"], "precio" => $row["precio"], "idioma" => $row["idioma"], "edicion" => $row["edicion"], "imagen" => $row["imagen"], "correoVendedor" => $row["correoVendedor"], "nombreVendedor" => $row["nombreVendedor"], "apellidoVendedor" => $row["apellidoVendedor"]);
					array_push($response, $dummyResponse);
				}
                $connection -> close();
				return $response;
			} else {
                $connection -> close();
				return array("status" => "409");
            }
        } else {
		  return array("status" => "500");
        }
        return array("status" => "500");	
    }

    function queryNombre($uNombre){
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM Libros WHERE nombreLibro = '$uNombre'";
			$result = $connection -> query($sql);
			if ($result ->num_rows > 0){
				$response = array();
				while($row = $result -> fetch_assoc()){
					$dummyResponse = array("status" => "EXITO","nombreLibro" => $row["nombreLibro"], "autor" => $row["autor"], "precio" => $row["precio"], "idioma" => $row["idioma"], "edicion" => $row["edicion"], "correoVendedor" => $row["correoVendedor"], "nombreVendedor" => $row["nombreVendedor"], "apellidoVendedor" => $row["apellidoVendedor"]);
					array_push($response, $dummyResponse);
				}
                $connection -> close();
				return $response;
			} else {
                $connection -> close();
				return array("status" => "410");
            }
        } else {
		  return array("status" => "500");
        }
        return array("status" => "500");
    }


    function queryAutor($uAutor){
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM Libros WHERE autor = '$uAutor'";
			$result = $connection -> query($sql);
			if ($result ->num_rows > 0){
				$response = array();
				while($row = $result -> fetch_assoc()){
					$dummyResponse = array("status" => "EXITO","nombreLibro" => $row["nombreLibro"], "autor" => $row["autor"], "precio" => $row["precio"], "idioma" => $row["idioma"], "edicion" => $row["edicion"], "correoVendedor" => $row["correoVendedor"], "nombreVendedor" => $row["nombreVendedor"], "apellidoVendedor" => $row["apellidoVendedor"]);
					array_push($response, $dummyResponse);
				}
                $connection -> close();
				return $response;
			} else {
                $connection -> close();
				return array("status" => "411");
            }
        } else {
		  return array("status" => "500");
        }
        return array("status" => "500");
    }

    function obtenerVendedor($uCorreo){
        		
		$connection = connectionToDataBase();

		if ($connection != null) {
			$sql = "SELECT * FROM usuarios WHERE correo ='$uCorreo'";
		
			$result = $connection->query($sql);
			if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $response = array("status" => "EXITO", "nombre"=>$row["nombre"], "apellido"=>$row["apellido"], "correo"=>$uCorreo);
                }
                $connection -> close();
                return $response;    
            } else {
				$connection -> close();
				return array("status" => "412");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
    }
 

    function modificarUsuario($uNombre, $uApellido, $uContrasena, $uCorreo) {
                		
		$connection = connectionToDataBase();

		if ($connection != null) {
			$sql = "UPDATE usuarios SET nombre='$uNombre', apellido='$uApellido', contrasena='$uContrasena' WHERE correo ='$uCorreo'";
			if ($connection->query($sql) === TRUE) {
                $response = array("status" => "EXITO", "nombre"=>$uNombre, "apellido"=>$uApellido, "correo"=>$uCorreo, "contrasena"=>$uContrasena);
                $connection -> close();
                return $response;    
            } else {
				$connection -> close();
				return array("status" => "413");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
    }

    function insertarFav($uNombre, $uCorreo) {
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM favoritos WHERE correo ='$uCorreo'";
            $result = $connection->query($sql);
			if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $libros = $row["libros"]  . ' ' . $uNombre;
                    
                    $sqldos = "UPDATE favoritos SET libros='$libros' WHERE correo='$uCorreo'";
                    if ($connection -> query($sqldos) === TRUE){
                        $response = array("status" => "EXITO");
                        $connection -> close();
                        return $response;
                    } else {
                        $connection -> close();
                        return array("status" => "414");
                    }
                }
                $connection -> close();
                return $response;    
            } else {
                $sqldos = "INSERT INTO favoritos (correo, libros) VALUES ('$uCorreo', '$uNombre')";
                if ($connection -> query($sqldos) === TRUE){
                    $response = array("status" => "EXITO");
                    $connection -> close();
                    return $response;
                } else {
                    $connection -> close();
                    return array("status" => "414");
                }
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
    }

/*
    function eliminarFav($uNombre, $uCorreo){
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM favoritos WHERE correo ='$uCorreo'";
            $result = $connection->query($sql);
			if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $iD = $row["ID"];
                    $libros = $row["libros"];
                    $librosIndividuales = $libros.split(' ');
                    while (var iC = 0; iC < $librosIndividuales.length; iC++){
                        if ($uNombre != $librosIndividuales[iC]){
                            $nuevosLibros = $nuevosLibros . ' ' . $librosIndividuales[iC];
                        }
                    }
                    $sqldos = "UPDATE favoritos SET correo='$uCorreo', libros='$nuevosLibros' WHERE ID ='$iD'";
                    if ($connection -> query($sqldos) === TRUE){
                        $response = array("status" => "EXITO");
                        $connection -> close();
                        return $response;
                    } else {
                        $connection -> close();
                        return array("status" => "416");
                    }
                }
            } else {
                $connection -> close();
                return array("status" => "415");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
    }
*/
    function desplegarFav($uCorreo){
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM favoritos WHERE correo ='$uCorreo'";
            $result = $connection->query($sql);
			if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
					$response = array("status" => "EXITO", "correo"=>$row["correo"], "libros"=>$row["libros"]);
                    $connection -> close();
                    return $response;    
                }
                $connection -> close();
                return $response;    
            } else {
                $connection -> close();
                return array("status" => "417");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
    }

    function attemptSubirL($nombreLibro, $autor, $imagen, $precio, $idioma, $edicion, $correoVendedor, $nombreVendedor, $apellidoVendedor) {	
		$connection = connectionToDataBase();

		if ($connection != null) {
			$sql = "SELECT * FROM Libros WHERE correo ='$correoVendedor'";
		
			$result = $connection->query($sql);

			if ($result->num_rows == 0) {
                $sqldos = "INSERT INTO Libros(nombreLibro, autor, imagen, precio, idioma, edicion, correoVendedor, nombreVendedor, apellidoVendedor) VALUES ('$nombreLibro', '$autor', '$imagen', '$precio', '$idioma', '$edicion', '$correoVendedor', '$nombreVendedor', '$apellidoVendedor')";
                    if ($connection -> query($sqldos) === TRUE){
                        $response = array("status" => "EXITO");
                        $connection -> close();
                        return $response;
                    } else {
                        $connection -> close();
                        return array("status" => "408");
                    }
            } else {
				$connection -> close();
				return array("status" => "407");
			}
		} else {
			return array("status" => "500");
		}
		return array("status" => "500");
	}

    function cargarLibrosSubidos($uCorreo){
        $connection = connectionToDataBase();
		if ($connection != null) {
			$sql = "SELECT * FROM libros WHERE correoVendedor ='$uCorreo'";
            $result = $connection->query($sql);
			if ($result->num_rows > 0) {
				$response = array();
                while ($row = $result->fetch_assoc()) {
					$dummyResponse = array("status" => "EXITO", "nombreLibro"=>$row["nombreLibro"]);
                    array_push($response, $dummyResponse);
                }
                $connection -> close();
                return $response;       
        } else {
            $connection -> close();
            return array("status" => "418");
        }
    } else {
        return array("status" => "500");
        }
        return array("status" => "500");
}

?>
