$(document).ready(function () {
    var $errorL = $("#errorL");
    $("#login").on("click", function () {
        if ($("#emailLo").val() != "" && $("#PassLo").val() != "") {
            var jsonToSend = {
                "uCorreo": $("#emailLo").val(),
                "uPassword": $("#PassLo").val(),
                "accion": "LOGIN"
            };
            $.ajax({
                url: "data/applicationLayer.php",
                type: "POST",
                data: jsonToSend,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonReceived) {
                   window.location.replace("home.html");
                },
                error: function (errorMessage) {
                    $("#errorLoginText").text(errorMessage.responseText);
                    $("#errorLoginText").css("color", "#5499c7");
                    $("#errorLogin").show(300);
                }
            });
        } else {
            $("#errorLoginText").text("Favor de llenar todos los datos.");
            $("#errorLoginText").css("color", "#5499c7");
            $("#errorLogin").show(300);
          
        }
    });

    $("#regis").on("click", function () {
        window.location.replace("registro.html");
    });
});
