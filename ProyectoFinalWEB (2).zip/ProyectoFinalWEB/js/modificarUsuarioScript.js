$(document).ready(function () {
    var jsonToSend = {
        "accion": "CARGARCUENTA"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            $("#nameM").val(jsonReceived.nombre);
            $("#apellidoM").val(jsonReceived.apellido);
            $("#passM").val(jsonReceived.contrasena);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    $("#modificar").on("click", function () {
        guardarDatosCuenta();
    });

    $("#lout").on("click", logoutUsuario);
});


function guardarDatosCuenta() {
    var jsonToSend = {
        "nombre": $("#nameM").val(),
        "apellido": $("#apellidoM").val(),
        "contrasena": $("#passM").val(),
        "accion": "GUARDARCUENTA"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            $("#notificacionGuardarText").text("Se han modificados los datos del usuario.");
            $("#notificacionGuardarText").css("color", "#5499c7");
            $("#notificacionGuardar").show(300);

            $("#nameM").val(jsonReceived.nombre);
            $("#apellidoM").val(jsonReceived.apellido);
            $("#passM").val(jsonReceived.contrasena);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

}

function logoutUsuario() {
    var jsonToSend = {
        "accion": "LOGUT"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            window.location.replace("index.html");
        },
        error: function (errorMessage) {
            console.log(errorMessage.responseText);
        }
    });
}
