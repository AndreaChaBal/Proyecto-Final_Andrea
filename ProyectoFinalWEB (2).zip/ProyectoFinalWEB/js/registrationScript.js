$(document).ready(function () {
    var $errorR = $("#errorR");
    $("#regis").on("click", function () {
        if ($("#nombre").val() != "" && $("#apellido").val() != "" && $("#email").val() != "" && $("#pass").val() != "") {
            var jsonObject = {
                "nombre": $("#nombre").val(),
                "apellido": $("#apellido").val(),
                "correo": $("#email").val(),
                "contrasena": $("#pass").val(),
                "accion": "REGISTRO"
            };

            $.ajax({
                type: "POST",
                url: "data/applicationLayer.php",
                data: jsonObject,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonData) {
                    window.location.replace("home.html");
                },
                error: function (errorMessage) {
                    $("#errorRegistroText").text(errorMessage.responseText);
                    $("#errorRegistroText").css("color", "#5499c7");
                    $("#errorRegistro").show(300);
                }
            });
        } else {
            $("#errorRegistroText").text("Llena todos los campos requeridos de registro.");
            $("#errorRegistroText").css("color", "#5499c7");
            $("#errorRegistro").show(300);
        }
    });

    $("#cancelar").on("click", function () {
        window.location.replace("index.html");
    });
});
