$(document).ready(function () {
    $("#subirB").on("click", function () {
        if ($("#name").val() != "" && $("#autor").val() != "" && $("#precio").val() != "" && $("#idioma").val() != "" && $("#edicion").val() != "" && $("#correoV").val() != "" && $("#nombreV").val() != "" && $("#apellidoV").val() != "") {
            var jsonObject = {
                "nombreLibro": $("#name").val(),
                "autor": $("#autor").val(),
                "imagen": $("#imagen").val(),
                "precio": $("#precio").val(),
                "idioma": $("#idioma").val(),
                "edicion": $("#edicion").val(),
                "correoVendedor": $("#correoV").val(),
                "nombreVendedor": $("#nombreV").val(),
                "apellidoVendedor": $("#apellidoV").val(),
                "accion": "SUBIRLIBRO"
            };

            $.ajax({
                type: "POST",
                url: "data/applicationLayer.php",
                data: jsonObject,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonData) {
                    $("#errorLibro").hide(300);

                },
                error: function (errorMessage) {
                    $("#errorLibroText").text(errorMessage.responseText);
                    $("#errorLibroText").css("color", "#5499c7");
                    $("#errorLibro").show(300);
                }
            });

        } else {
            $("#errorLibroText").text("Llena todos los campos requeridos de registro.");
            $("#errorLibroText").css("color", "#5499c7");
            $("#errorLibro").show(300);
        }
    });
    var jsonToSend = {
        "accion": "SUBIDOS"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (librosSubidosJSON) {
            var libros = "";
            for (var iC = 0; iC < librosSubidosJSON.length; iC++) {
                libros += "<center> <div><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Nombre: " +
                    "</font></b>" + librosSubidosJSON[iC].nombreLibro +
                    "</br>  </p> </div> </div> </center>";
            }
            $("#librosSubidos").html(libros);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    $("#lout").on("click", logoutUsuario);
});

function logoutUsuario() {
    var jsonToSend = {
        "accion": "LOGUT"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            window.location.replace("index.html");
        },
        error: function (errorMessage) {
            console.log(errorMessage.responseText);
        }
    });
}
