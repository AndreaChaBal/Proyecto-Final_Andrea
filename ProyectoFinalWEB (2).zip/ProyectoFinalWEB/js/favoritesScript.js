$(document).ready(function () {
    var jsonToSend = {
        "accion": "MOSTRARFAVORITO"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (favsJSON) {
            var favs = "";
            console.log(favsJSON.libros);
            var arrFavs = favsJSON.libros.split(' ');
            for (var iC = 0; iC < arrFavs.length; iC++) {
                favs += "<center><div><div style= 'text-align: left; display: inline-block;'><p> <b class='nomLibro'>" + "<font color='orange'>" + "Nombre del libro: " +
                    "</font></b>" + arrFavs[iC] +
                    "</br>  </p> </div> </div></center>";
            }
            $("#librosF").html(favs);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    $("#lout").on("click", logoutUsuario);
});

function logoutUsuario() {
    var jsonToSend = {
        "accion": "LOGUT"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            window.location.replace("index.html");
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });
}
