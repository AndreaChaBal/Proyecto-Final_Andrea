$(document).ready(function () {
    var jsonToSend = {
        "accion": "CATALOGO"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (librosJSON) {
            var libros = "";
            for (var iC = 0; iC < librosJSON.length; iC++) {
                libros += "<div><div style= 'text-align: left; display: inline-block;'><p> <b class='nomLibro'>" + "<font color='orange'>" + "Nombre: " +
                    "</font></b>" + librosJSON[iC].nombreLibro +
                    "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Autor: " +
                    "</font></b>" + librosJSON[iC].autor + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Idioma: " +
                    "</font></b>" + librosJSON[iC].idioma + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Edición: " +
                    "</font></b>" + librosJSON[iC].edicion + "</br> </p> ";
                libros += "<img src= '" + librosJSON[iC].imagen + "'>";
                libros += "<p > <b>" + "<font color='orange'>" + "Precio: " +
                    "</font></b>" + "$" + librosJSON[iC].precio + ".00" + "</br> </p>";
                libros += "<input type='checkbox' name='favorite' class='favoritoCatalogo'/>" +
                    "Favoritos" + "</br>" + "</div> </div>";
                libros += "<button class='botonesMas' style= 'margin: 10px; type='button'>Más información</button>";
                libros += "<div class='hiddenElement'><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Vendedor: " +
                    "</font></b>" + librosJSON[iC].nombreVendedor + " " + librosJSON[iC].apellidoVendedor + "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Correo de contacto: " + "</font></b>" + librosJSON[iC].correoVendedor + "</br> </p>" + " </div> </div>";
            }
            $("#librosJson").html(libros);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    $("#bot").on("click", hacerQuery);
    $("#librosJson").on("click", "button", function () {
        $(this).next().removeClass("hiddenElement");
    });

    $("#lout").on("click", logoutUsuario);

    $("#librosJson").on("click", "input", function () {
        $datos = $(this).parent().parent().first().text();
        $nombreLibro = ($datos.split(':')[1].split("    ")[0].trim());
        if ($(this).is(':checked') == true) {
            var jsonToSend = {
                "nombre": $nombreLibro,
                "accion": "AGREGARFAVORITO"
            };
            $.ajax({
                url: "data/applicationLayer.php",
                type: "POST",
                data: jsonToSend,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonReceived) {},
                error: function (errorMessage) {
                    console.log(errorMessage);
                }
            });
        } else {
            /*
            var jsonToSend = {
                "nombre": $nombreLibro,
                "accion": "QUITARFAVORITO"
            };
            $.ajax({
                url: "data/applicationLayer.php",
                type: "POST",
                data: jsonToSend,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonReceived) {},
                error: function (errorMessage) {
                    console.log(errorMessage);
                }
            });
            */
        }
    });
});

function logoutUsuario() {
    var jsonToSend = {
        "accion": "LOGUT"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonReceived) {
            window.location.replace("index.html");
        },
        error: function (errorMessage) {
            console.log(errorMessage.responseText);
        }
    });
}

function hacerQuery() {
    var valorTipoQuery = $("input[name=check]:checked").val();
    if (valorTipoQuery == "nombreLibro") {
        hacerQueryNombre();
    } else {
        hacerQueryAutor();
    }
}

function hacerQueryNombre() {
    $("#errorQuery").hide();
    var jsonToSend = {
        "nombre": $("#searchLibro").val(),
        "accion": "PORNOMBRE"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (librosJSON) {
            var libros = "";
            for (var iC = 0; iC < librosJSON.length; iC++) {
                libros += "<div><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Nombre: " +
                    "</font></b>" + librosJSON[iC].nombreLibro +
                    "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Autor: " +
                    "</font></b>" + librosJSON[iC].autor + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Idioma: " +
                    "</font></b>" + librosJSON[iC].idioma + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Edición: " +
                    "</font></b>" + librosJSON[iC].edicion + "</br> </p> ";
                libros += "<img src= '" + librosJSON[iC].imagen + "'>";
                libros += "<p > <b>" + "<font color='orange'>" + "Precio: " +
                    "</font></b>" + "$" + librosJSON[iC].precio + ".00" + "</br> </p>";
                libros += "<input type='checkbox' name='favorite' class='favoritoCatalogo'/>" +
                    "Favoritos" + "</br>" + "</div> </div>";
                libros += "<button class='botonesMas' style= 'margin: 10px; type='button'>Más información</button>";
                libros += "<div class='hiddenElement'><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Vendedor: " +
                    "</font></b>" + librosJSON[iC].nombreVendedor + " " + librosJSON[iC].apellidoVendedor + "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Correo de contacto: " + "</font></b>" + librosJSON[iC].correoVendedor + "</br> </p>" + " </div> </div>";
            }
            $("#librosJson").html(libros);
        },
        error: function (errorMessage) {
            $("#librosJson").html("");
            $("#errorQueryText").text(errorMessage.responseText);
            $("#errorQueryText").css("color", "#5499c7");
            $("#errorQuery").show(300);
        }
    });
}



function hacerQueryAutor() {
    $("#errorQuery").hide();
    var jsonToSend = {
        "autor": $("#searchLibro").val(),
        "accion": "PORAUTOR"
    };
    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (librosJSON) {
            var libros = "";
            for (var iC = 0; iC < librosJSON.length; iC++) {
                libros += "<div><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Nombre: " +
                    "</font></b>" + librosJSON[iC].nombreLibro +
                    "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Autor: " +
                    "</font></b>" + librosJSON[iC].autor + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Idioma: " +
                    "</font></b>" + librosJSON[iC].idioma + "</br>  </p>";
                libros += "<p> <b>" + "<font color='orange'>" + "Edición: " +
                    "</font></b>" + librosJSON[iC].edicion + "</br> </p> ";
                libros += "<img src= '" + librosJSON[iC].imagen + "'>";
                libros += "<p > <b>" + "<font color='orange'>" + "Precio: " +
                    "</font></b>" + "$" + librosJSON[iC].precio + ".00" + "</br> </p>";
                libros += "<input type='checkbox' name='favorite' class='favoritoCatalogo'/>" +
                    "Favoritos" + "</br>" + "</div> </div>";
                libros += "<button class='botonesMas' style= 'margin: 10px; type='button'>Más información</button>";
                libros += "<div class='hiddenElement'><div style= 'text-align: left; display: inline-block;'><p> <b>" + "<font color='orange'>" + "Vendedor: " +
                    "</font></b>" + librosJSON[iC].nombreVendedor + " " + librosJSON[iC].apellidoVendedor + "</br>  </p> ";
                libros += "<p> <b>" + "<font color='orange'>" + "Correo de contacto: " + "</font></b>" + librosJSON[iC].correoVendedor + "</br> </p>" + " </div> </div>";
            }
            $("#librosJson").html(libros);
        },
        error: function (errorMessage) {
            $("#librosJson").html("");
            $("#errorQueryText").text(errorMessage.responseText);
            $("#errorQueryText").css("color", "#5499c7");
            $("#errorQuery").show(300);
        }
    });
}
